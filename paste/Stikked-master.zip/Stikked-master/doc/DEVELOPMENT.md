You want to improve Stikked? Always welcome! Send us your pull request and you will be honoured in AUTHORS.md.

Some guidelines:

* Coding style: PSR-2. For PHP files (not views/themes), please run phpfmt (https://marketplace.visualstudio.com/items?itemName=kokororin.vscode-phpfmt).
* Other people may modify your contribution. Don't take that personal; we all want to improve Stikked. Your input is always welcome!
