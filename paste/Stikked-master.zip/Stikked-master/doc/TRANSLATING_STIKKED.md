How to translate Stikked into your own language
-----------------------------------------------

1. Make a copy of the folder `htdocs/application/language/swissgerman`, and name it as you like.
2. Start placing in your translated text!

The date_lang.php and form_validation_lang.php are optional; they lay in the system folder for english fallback. stikked_lang.php is required. If you miss a translation, it will be shown as [translation_index] in Stikked.
